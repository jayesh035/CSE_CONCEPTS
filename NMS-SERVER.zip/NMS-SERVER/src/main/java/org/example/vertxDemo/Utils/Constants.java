package org.example.vertxDemo.Utils;

public class Constants
{
    public static final String DB_USERNAME="postgres";
    public static final String DB_PASSWORD="jayesh";
    public static final int DB_PORT=5432;
    public static final String DB_NAME="postgres";
    public static final String DB_HOST="localhost";
    public static final int SERVER_PORT=8080;
    public static final String JWT_KEY="ANYrCXMA5ucLjT20x9qjaVw+HItkI9XGsBHUj/xtPJQ=";
}
